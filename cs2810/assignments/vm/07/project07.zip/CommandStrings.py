#Define all command strings

eqInit = \
"""
    //Reference to EQ command
(_EQ)
@R15
M=D

A=D
D=M
D=D-M
@_EQ_TRUE
D;JEQ
    //Is not equal, push false
@0
D=A
@SP
AM=M+1
A=A-1
M=D
@_EQ_END
0;JMP
(_EQ_TRUE)
    //Is equal, push true
@-1
D=A
@SP
AM=M+1
A=A-1
M=D
(_EQ_END)
@R15
0;JMP
    //End EQ
"""

ltInit = \
"""
    //Reference to LT command
(_LT)
@R15
M=D

A=D
D=M
D=D-M
@_LT_TRUE
D;JLT
    //Is not less than, push false
@0
D=A
@SP
AM=M+1
A=A-1
M=D
@_LT_END
0;JMP
(_LT_TRUE)
    //Is less than, push true
@-1
D=A
@SP
AM=M+1
A=A-1
M=D
(_LT_END)
@R15
0;JMP
    //End LT
"""

gtInit = \
"""
    //Reference to GT command
(_GT)
@R15
M=D

A=D
D=M
D=D-M
@_GT_TRUE
D;JGT
    //Is not less than, push false
@0
D=A
@SP
AM=M+1
A=A-1
M=D
@_GT_END
0;JMP
(_GT_TRUE)
    //Is less than, push true
@-1
D=A
@SP
AM=M+1
A=A-1
M=D
(_GT_END)
@R15
0;JMP
    //End GT
"""

eqInstance = \
"""@_EQ_%s
D=A
@_EQ
0;JMP
(_EQ_%s)"""

ltInstance = \
"""@_LT_%s
D=A
@_LT
0;JMP
(_LT_%s)"""

gtInstance = \
"""_GT_%s
D=A
@_GT
0;JMP
(_GT_%s)"""

addInstance = \
"""@SP
A=M-1
D=M
A=A-1
M=D+M
D=A+1
@SP
M=D"""

negInstance = \
"""@SP
A=M-1
D=M
@0
D=A-D
@SP
A=M-1
M=D"""

subInstance = \
"""@SP
A=M-1
D=M
A=A-1
M=M-D
D=A+1
@SP
M=D"""

andInstance = \
"""@SP
AM=M-1
D=M
A=A-1
M=D&M"""

orInstance = \
"""@SP
AM=M-1
D=M
A=A-1
M=D|M"""

notInstance = \
"""@SP
A=M-A
M=!M"""

haltInstance = \
"""(HALT)
@HALT
0;JMP"""

pushInstance = \
"""@SP
A=M
M=D
D=A+1
@SP
M=D"""

pushConstant = \
"""@%s
D=A
@SP
A=M
M=D
D=A+1
@SP
M=D"""

pushFromInstance = \
"""@%s
A=D+A
D=M"""

popInstance = \
"""@SP
M=M-1
A=M
D=M"""

staticPop = \
"""D=%S"""

locationSetD = \
"""@%s
D=D+A"""

locationSetMemory = \
"""@%s
M=D"""

locationInMemory = \
"""@%s
D=M"""

locationIsMemory = \
"""@R%s
D=A"""

popCommand = \
"""@R13
M=D
@SP
A=M
A=A-1
D=M
@R13
A=M
M=D
@SP
A=M
A=A-1
D=A
@SP
M=D"""
