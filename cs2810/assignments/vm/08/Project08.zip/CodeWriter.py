import sys, os
from CommandStrings import *

class CodeWriter:
    def __init__(self, filestream):
        self.__filestream = filestream
        self.__filename = None

        self.__eqCount = 0
        self.__gtCount = 0
        self.__ltCount = 0
        self.__retCount = 0

        self.__segmentDict = {
            "local" : "LCL",
            "argument" : "ARG",
            "this" : "THIS",
            "that" : "THAT"}

    def getFilestream(self):
        return self.__filestream
    Filestream = property(getFilestream)

    def setFileName(self, filename):
        self.__filename = filename
    Filename = property(None, setFileName)

    def write(self, string):
        print >>self.__filestream, string

    def writePushPop(self, command, segment, index):
        self.write("\t//%s %s %s" % (command, segment, index))

        if segment in self.__segmentDict:
            segment = self.__segmentDict[segment]

        if command == "push":
            if segment == "constant":
                self.write(pushConstant % index)
            elif segment == "static":
                address = "%s.%s" % (self.__filename, index)
                self.write(pushTemp % address)
            elif segment == "pointer":
                address = index
                if index == 0:
                    address = "R3"
                if index == 1:
                    address = "R4"
                self.write(pushTemp % address)
            elif segment == "temp":
                address = "R%s" % (index + 5)
                self.write(pushTemp % address)
            else:
                self.write(pushLocal % (index, segment))
        elif command == "pop":
            if segment == "static":
                address = "%s.%s" % (self.__filename, index)
                self.write(popTemp % address)
            elif segment == "pointer":
                address = index
                if index == 0:
                    address = "R3"
                if index == 1:
                    address = "R4"
                self.write(popTemp % address)
            elif segment == "temp":
                address = "R%s" % (index + 5)
                self.write(popTemp % (address))
            else:
                self.write(popLocal % (index, segment))
                

    def writeArithmetic(self, command):
        self.write("\t//%s" % (command))
        
        if command == "eq":
            self.write(eqInstance % (self.__eqCount, self.__eqCount))
            self.__eqCount += 1
        elif command == "lt":
            self.write(ltInstance % (self.__ltCount, self.__ltCount))
            self.__ltCount += 1
        elif command == "gt":
            self.write(gtInstance % (self.__gtCount, self.__gtCount))
            self.__gtCount += 1
        elif command == "add":
            self.write(addInstance)
        elif command == "sub":
            self.write(subInstance)
        elif command == "neg":
            self.write(negInstance)
        elif command == "and":
            self.write(andInstance)
        elif command == "not":
            self.write(notInstance)
        elif command == "or":
            self.write(orInstance)

    def writeGoto(self, command, label):
        self.write("//%s %s" % (command, label))

        self.write(pushGoto % label)
        
    def writeIfGoto(self, command, label):
        self.write("//%s %s" % (command, label))

        self.write(pushIfGoto % label)
    def writeLabel(self, command, label):
        self.write("//%s %s" % (command, label))

        self.write("(%s)" % label)

    def writeFunction(self, command, label, args):
        self.write("//%s %s %s" % (command, label, args))

        self.write("(%s)" % label)
        self.write(pushArgInit)
        for i in range(args):
            self.write(pushArg)
        self.write(pushArgEnd)

    def writeCall(self, command, function, args):
        self.write("//%s %s %s" % (command, function, args))

        self.write(pushCallFunction % (args, function, self.__retCount, self.__retCount))
        self.__retCount += 1

    def writeReturn(self, command):
        self.write("//%s" % command)
        self.write(pushCallRoutine)
        self.write(pushReturn)

    def writePreamble(self, command, function, args):
        self.write("//Preamble")
        self.write("//%s %s %s" % (command, function, args))

        self.write(pushPreamble)
        self.write(pushCallFunction % (args, function, self.__retCount, self.__retCount))
        self.__retCount += 1

    def writePost(self):
        self.write(haltInstance)
        if self.__eqCount > 0:
            self.write(eqInit)
        if self.__ltCount > 0:
            self.write(ltInit)
        if self.__gtCount > 0:
            self.write(gtInit)



            
