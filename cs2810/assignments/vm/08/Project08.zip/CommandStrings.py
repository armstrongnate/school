#Define all command strings

eqInit = \
"""
    //Reference to GT command
(_EQ)
@R15
M=D

@SP
AM=M-1
D=M
A=A-1
D=M-D
@_EQ_FALSE
D;JNE
    //Is less than, push true.
A=-1
D=A
@SP
A=M-1
M=D
@_EQ_END
0;JMP
(_EQ_FALSE)
    //Is not greater than, push false.
@0
D=A
@SP
A=M-1
M=D
(_EQ_END)
@R15
A=M
0;JMP
    //End GT
"""

ltInit = \
"""
    //Reference to GT command
(_LT)
@R15
M=D

@SP
AM=M-1
D=M
A=A-1
D=M-D
@_LT_FALSE
D;JGE
    //Is less than, push true.
A=-1
D=A
@SP
A=M-1
M=D
@_LT_END
0;JMP
(_LT_FALSE)
    //Is not greater than, push false.
@0
D=A
@SP
A=M-1
M=D
(_LT_END)
@R15
A=M
0;JMP
    //End GT
"""

gtInit = \
"""
    //Reference to GT command
(_GT)
@R15
M=D

@SP
AM=M-1
D=M
A=A-1
D=D-M
@_GT_FALSE
D;JGE
    //Is greater than, push true.
A=-1
D=A
@SP
A=M-1
M=D
@_GT_END
0;JMP
(_GT_FALSE)
    //Is not greater than, push false.
@0
D=A
@SP
A=M-1
M=D
(_GT_END)
@R15
A=M
0;JMP
    //End GT
"""

eqInstance = \
"""@_EQ_%s
D=A
@_EQ
0;JMP
(_EQ_%s)"""

ltInstance = \
"""@_LT_%s
D=A
@_LT
0;JMP
(_LT_%s)"""

gtInstance = \
"""@_GT_%s
D=A
@_GT
0;JMP
(_GT_%s)"""

addInstance = \
"""@SP
AM=M-1
D=M
A=A-1
M=D+M"""

negInstance = \
"""@SP
A=M-1
M=-M"""

subInstance = \
"""@SP
AM=M-1
D=M
A=A-1
M=M-D"""

andInstance = \
"""@SP
AM=M-1
D=M
A=A-1
M=D&M"""

orInstance = \
"""@SP
AM=M-1
D=M
A=A-1
M=D|M"""

notInstance = \
"""@SP
A=M-1
M=!M"""

haltInstance = \
"""(HALT)
@HALT
0;JMP"""

pushConstant = \
"""@%s
D=A
@SP
AM=M+1
A=A-1
M=D"""

pushTemp = \
"""@%s
D=M
@SP
AM=M+1
A=A-1
M=D"""

pushArgInit = \
"""@SP
A=M"""

pushArg = \
"""M=0
AD=A+1"""

pushArgEnd = \
"""@SP
M=D
@_RETURN
0;JMP"""

pushReturn = \
"""(_RETURN)
@5
D=A
@LCL
A=M-D
D=M
@R13
M=D
@SP
AM=M-1
D=M
@ARG
A=M
M=D
D=A
@SP
M=D+1
@LCL
D=M
@R14
AM=d-1
D=M
@THAT
M=D
$14
AM=M-1
D=M
@THIS
M=D
@R14
AM=M-1
D=M
@ARG
M=D
@R14
AM=M-1
D=M
@LCL
M=D
@R13
A=M
0;JMP"""

pushPreamble = \
"""@256
D=A
@SP
M=D"""

pushCallFunction = \
"""@%s //ARG COUNT
D=A
@R13
M=D
@%s //FUNCTION
D=A
@R14
M=D
@_RETURN_%s
D=A
@_CALL
0;JMP
(_RETURN_%s)"""

pushIfGoto = \
"""@SP
AM=M-1
D=M
@%s
0;JEQ"""

pushGoto = \
"""@%s
0;JMP"""

pushCallRoutine = \
"""(_CALL)
@SP
A=M
M=D
@LCL
D=M
@SP
AM=M+1
M=D
@ARG
D=M
@SP
AM=M+1
M=D
@THIS
D=M
@SP
AM=M+1
M=D
@THAT
D=M
@SP
AM=M+1
M=D
@4
D=A
@R13
D=D+M
@SP
D=M-D
@ARG
M=D
@SP
MD=M+1
@LCL
M=D
@R14
A=M
0;JMP"""

pushLocal = \
"""@%s
D=A
@%s
A=D+M
D=M
@SP
AM=M+1
A=A-1
M=D"""

popTemp = \
"""@SP
AM=M-1
D=M
@%s
M=D"""

popLocal = \
"""@%s
D=A
@%s
D=D+M
@R15
M=D
@SP
AM=M-1
D=M
@R15
A=M
M=D"""
