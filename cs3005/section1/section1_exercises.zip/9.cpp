#include <iostream>
using namespace std;

int main ()
{
	int num, i;
	cout << "Enter a number: ";
	cin >> num;
	for (i=1; i<=num; i++)
	{
		cout << "hello" << endl;
	}
}
