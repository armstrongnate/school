#include <iostream>

int main ()
{
	int x, y;
	x = 7;
	y = 3*4+(x-5)*8;
    std::cout << y;
    return 0;
}