#include <iostream>
using namespace std;

int main ()
{
	int a, b, c;
	cout << "Value for a: ";
	cin >> a;
	cout << "Value for b: ";
	cin >> b;
	c = a + b;
    cout << c;
    return 0;
}