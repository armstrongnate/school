#include <iostream>

int main ()
{
    std::cout << "Ring around the rosie, pockets full of posie. Ashes, ashes, we all fall down!";
    return 0;
}