#include <iostream>
using namespace std;

int main ()
{
	int num;
	cout << "Give me a number: ";
	cin >> num;
	if (num > 0)
	{
		cout << "Positive";
	}
    return 0;
}