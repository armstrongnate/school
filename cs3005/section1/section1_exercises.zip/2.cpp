#include <iostream>

int main ()
{
    std::cout << 3*4+(7-5)*8;
    return 0;
}